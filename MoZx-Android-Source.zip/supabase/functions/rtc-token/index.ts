// Supabase Edge Function: authenticated, short-lived Agora RTC token.
// Set AGORA_APP_ID and AGORA_APP_CERTIFICATE as server secrets; never ship them in the app.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { RtcRole, RtcTokenBuilder } from 'npm:agora-token@2.0.5';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const reply = (body: unknown, status=200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type':'application/json' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return reply({ error:'POST required' },405);
  const url=Deno.env.get('SUPABASE_URL'), anon=Deno.env.get('SUPABASE_ANON_KEY'), service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const appId=Deno.env.get('AGORA_APP_ID'), cert=Deno.env.get('AGORA_APP_CERTIFICATE');
  if (!url || !anon || !service || !appId || !cert) return reply({error:'Voice service is not configured'},503);
  const authHeader=req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) return reply({error:'Sign-in required'},401);
  const userClient=createClient(url,anon,{global:{headers:{Authorization:authHeader}}});
  const {data:{user},error:authError}=await userClient.auth.getUser();
  if (authError || !user) return reply({error:'Invalid session'},401);
  let input; try { input=await req.json(); } catch { return reply({error:'Invalid request'},400); }
  if (typeof input.roomId!=='string' || !/^[0-9a-f-]{36}$/i.test(input.roomId)) return reply({error:'Invalid room'},400);
  const db=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:room,error:roomError}=await db.from('rooms').select('id,status,visibility').eq('id',input.roomId).maybeSingle();
  if (roomError || !room || room.status!=='open') return reply({error:'Room unavailable'},404);
  const {data:member}=await db.from('room_participants').select('role').eq('room_id',room.id).eq('user_id',user.id).maybeSingle();
  if (!member) return reply({error:'Join the room before requesting voice access'},403);
  const {data:profile}=await db.from('profiles').select('numeric_id').eq('user_id',user.id).single();
  const uid=Number(profile?.numeric_id);
  if (!Number.isSafeInteger(uid) || uid<=0) return reply({error:'Account is not ready'},409);
  const channel=`mozx_${room.id}`;
  const now=Math.floor(Date.now()/1000), expires=now+3600;
  const role=member.role==='listener' ? RtcRole.SUBSCRIBER : RtcRole.PUBLISHER;
  const token=RtcTokenBuilder.buildTokenWithUid(appId,cert,channel,uid,role,3600,3600);
  return reply({appId,channel,uid,token,expiresAt:expires});
});
