-- MoZx foundation (Supabase/Postgres). Apply with Supabase CLI as a migration.
-- Sensitive mutations (roles, wallet, gifts, moderation) are server-only by design.
create extension if not exists pgcrypto;
create sequence if not exists public.mozx_numeric_id_seq start 100001;
create table if not exists public.profiles(
 user_id uuid primary key references auth.users(id) on delete cascade,
 numeric_id bigint not null unique default nextval('public.mozx_numeric_id_seq'),
 username text not null default 'New member' check(length(username) between 2 and 32),
 avatar_url text, country text, bio text not null default '' check(length(bio)<=300),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.profile_private(
 user_id uuid primary key references auth.users(id) on delete cascade,
 gender text, birthday date, privacy jsonb not null default '{}'::jsonb
);
create or replace function public.mozx_new_profile() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(user_id) values(new.id) on conflict do nothing; insert into public.profile_private(user_id) values(new.id) on conflict do nothing; return new; end $$;
drop trigger if exists mozx_auth_user_created on auth.users;
create trigger mozx_auth_user_created after insert on auth.users for each row execute function public.mozx_new_profile();

create table if not exists public.roles(
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null check(role in ('owner','super_admin','manager','assistant_manager','bd_manager','room_moderator')),
 active boolean not null default true, assigned_by uuid references auth.users(id), assigned_at timestamptz not null default now(),
 primary key(user_id,role)
);
create table if not exists public.rooms(
 id uuid primary key default gen_random_uuid(), room_id bigint generated always as identity unique,
 owner_id uuid not null references auth.users(id), name text not null check(length(name) between 2 and 60),
 cover_url text, country text, visibility text not null default 'public' check(visibility in ('public','private')),
 seat_limit smallint not null default 15 check(seat_limit in (15,25,35,45)), status text not null default 'open' check(status in ('open','closed')),
 created_at timestamptz not null default now()
);
create table if not exists public.room_secrets(room_id uuid primary key references public.rooms(id) on delete cascade, password_hash text not null);
create table if not exists public.room_participants(
 room_id uuid references public.rooms(id) on delete cascade, user_id uuid references auth.users(id) on delete cascade,
 role text not null default 'listener' check(role in ('owner','moderator','speaker','listener')),
 seat smallint, joined_at timestamptz not null default now(), muted boolean not null default false,
 primary key(room_id,user_id), unique(room_id,seat)
);
create table if not exists public.room_messages(
 id uuid primary key default gen_random_uuid(), room_id uuid not null references public.rooms(id) on delete cascade,
 sender_id uuid not null references auth.users(id), body text not null check(length(body) between 1 and 1000), created_at timestamptz not null default now()
);
create table if not exists public.conversations(id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now());
create table if not exists public.conversation_members(conversation_id uuid references public.conversations(id) on delete cascade,user_id uuid references auth.users(id) on delete cascade, primary key(conversation_id,user_id));
create table if not exists public.messages(id uuid primary key default gen_random_uuid(), conversation_id uuid not null references public.conversations(id) on delete cascade,sender_id uuid not null references auth.users(id),body text not null check(length(body) between 1 and 5000),created_at timestamptz not null default now());
create table if not exists public.wallets(user_id uuid primary key references auth.users(id) on delete cascade, coin_balance bigint not null default 0 check(coin_balance>=0), updated_at timestamptz not null default now());
create table if not exists public.wallet_ledger(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),kind text not null check(kind in ('purchase','gift_sent','gift_received','reward','refund','adjustment')),coin_delta bigint not null check(coin_delta<>0), idempotency_key text not null, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now(), unique(user_id,idempotency_key));
create table if not exists public.daily_reward_claims(user_id uuid not null references auth.users(id),claim_date date not null,day_no smallint not null check(day_no between 1 and 7),coins integer not null,ledger_id uuid references public.wallet_ledger(id),created_at timestamptz not null default now(),primary key(user_id,claim_date));
create table if not exists public.gifts(id uuid primary key default gen_random_uuid(),name text not null,category text not null check(category in ('Basic','Premium','Luxury','VIP')),coin_price bigint not null check(coin_price>0),asset_url text,enabled boolean not null default false);
create table if not exists public.gift_events(id uuid primary key default gen_random_uuid(),sender_id uuid not null references auth.users(id),recipient_id uuid not null references auth.users(id),room_id uuid references public.rooms(id),gift_id uuid not null references public.gifts(id),quantity integer not null check(quantity between 1 and 100),created_at timestamptz not null default now());
create table if not exists public.posts(id uuid primary key default gen_random_uuid(),author_id uuid not null references auth.users(id),body text not null default '' check(length(body)<=3000),media_url text,privacy text not null default 'public' check(privacy in ('public','followers','private')),status text not null default 'published' check(status in ('published','hidden','removed')),created_at timestamptz not null default now());
create table if not exists public.follows(follower_id uuid references auth.users(id) on delete cascade,followed_id uuid references auth.users(id) on delete cascade,created_at timestamptz not null default now(),primary key(follower_id,followed_id),check(follower_id<>followed_id));
create table if not exists public.post_likes(post_id uuid references public.posts(id) on delete cascade,user_id uuid references auth.users(id) on delete cascade,created_at timestamptz not null default now(),primary key(post_id,user_id));
create table if not exists public.post_comments(id uuid primary key default gen_random_uuid(),post_id uuid not null references public.posts(id) on delete cascade,user_id uuid not null references auth.users(id),body text not null check(length(body) between 1 and 1000),created_at timestamptz not null default now());
create table if not exists public.user_blocks(blocker_id uuid references auth.users(id) on delete cascade,blocked_id uuid references auth.users(id) on delete cascade,created_at timestamptz not null default now(),primary key(blocker_id,blocked_id),check(blocker_id<>blocked_id));
create table if not exists public.reports(id uuid primary key default gen_random_uuid(),reporter_id uuid not null references auth.users(id),target_type text not null,target_id text not null,reason text not null check(length(reason)<=1000),status text not null default 'open',created_at timestamptz not null default now());
create table if not exists public.applications(id uuid primary key default gen_random_uuid(),applicant_id uuid not null references auth.users(id),kind text not null check(kind in ('room_theme','host','agency')),payload jsonb not null default '{}'::jsonb,status text not null default 'pending' check(status in ('pending','approved','rejected')),reviewer_id uuid references auth.users(id),review_reason text,reviewed_at timestamptz,created_at timestamptz not null default now());
create table if not exists public.audit_logs(id uuid primary key default gen_random_uuid(),actor_id uuid references auth.users(id),action text not null,target_type text,target_id text,details jsonb not null default '{}'::jsonb,created_at timestamptz not null default now());
create table if not exists public.notifications(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),kind text not null,payload jsonb not null default '{}'::jsonb,read_at timestamptz,created_at timestamptz not null default now());

-- Every table defaults to deny. The exposed policies below are intentionally small.
do $$ declare t text; begin foreach t in array array['profiles','profile_private','roles','rooms','room_secrets','room_participants','room_messages','conversations','conversation_members','messages','wallets','wallet_ledger','daily_reward_claims','gifts','gift_events','posts','follows','post_likes','post_comments','user_blocks','reports','applications','audit_logs','notifications'] loop execute format('alter table public.%I enable row level security',t); end loop; end $$;
create policy profiles_read_signed_in on public.profiles for select to authenticated using(true);
create policy profiles_update_self on public.profiles for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
revoke update on public.profiles from authenticated;
grant update(username,avatar_url,country,bio) on public.profiles to authenticated;
create policy private_read_self on public.profile_private for select to authenticated using(user_id=auth.uid());
create policy private_edit_self on public.profile_private for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy rooms_public_read on public.rooms for select to authenticated using((visibility='public' and status='open') or owner_id=auth.uid());
create policy rooms_owner_insert on public.rooms for insert to authenticated with check(owner_id=auth.uid());
create policy rooms_owner_update on public.rooms for update to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy participants_read_self on public.room_participants for select to authenticated using(user_id=auth.uid());
create policy room_chat_read_member on public.room_messages for select to authenticated using(exists(select 1 from public.room_participants p where p.room_id=room_messages.room_id and p.user_id=auth.uid()));
create policy room_chat_send_member on public.room_messages for insert to authenticated with check(sender_id=auth.uid() and exists(select 1 from public.room_participants p where p.room_id=room_messages.room_id and p.user_id=auth.uid()));
create policy conversations_member_read on public.conversations for select to authenticated using(exists(select 1 from public.conversation_members m where m.conversation_id=conversations.id and m.user_id=auth.uid()));
create policy members_self_read on public.conversation_members for select to authenticated using(user_id=auth.uid());
create policy messages_member_read on public.messages for select to authenticated using(exists(select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid()));
create policy messages_member_send on public.messages for insert to authenticated with check(sender_id=auth.uid() and exists(select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid()));
create policy wallet_read_self on public.wallets for select to authenticated using(user_id=auth.uid());
create policy ledger_read_self on public.wallet_ledger for select to authenticated using(user_id=auth.uid());
create policy claims_read_self on public.daily_reward_claims for select to authenticated using(user_id=auth.uid());
create policy gift_catalog_read on public.gifts for select to authenticated using(enabled=true);
create policy gifts_received_read on public.gift_events for select to authenticated using(sender_id=auth.uid() or recipient_id=auth.uid());
create policy posts_read_public on public.posts for select to authenticated using(status='published' and (privacy='public' or author_id=auth.uid()));
create policy posts_insert_self on public.posts for insert to authenticated with check(author_id=auth.uid());
create policy posts_update_self on public.posts for update to authenticated using(author_id=auth.uid()) with check(author_id=auth.uid());
create policy follows_read_signed_in on public.follows for select to authenticated using(true);
create policy follows_self_insert on public.follows for insert to authenticated with check(follower_id=auth.uid());
create policy follows_self_delete on public.follows for delete to authenticated using(follower_id=auth.uid());
create policy likes_read_signed_in on public.post_likes for select to authenticated using(true);
create policy likes_self_write on public.post_likes for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy comments_read_signed_in on public.post_comments for select to authenticated using(true);
create policy comments_self_insert on public.post_comments for insert to authenticated with check(user_id=auth.uid());
create policy blocks_self_all on public.user_blocks for all to authenticated using(blocker_id=auth.uid()) with check(blocker_id=auth.uid());
create policy reports_submit_self on public.reports for insert to authenticated with check(reporter_id=auth.uid());
create policy applications_submit_self on public.applications for insert to authenticated with check(applicant_id=auth.uid());
create policy applications_read_self on public.applications for select to authenticated using(applicant_id=auth.uid());
create policy notifications_read_self on public.notifications for select to authenticated using(user_id=auth.uid());

-- UTC server-day, Monday-start seven-day schedule. Unique daily claim + row lock + ledger key prevent replay.
create or replace function public.claim_daily_reward() returns table(claim_day date, reward_day smallint, coins_awarded integer, new_balance bigint)
language plpgsql security definer set search_path=public,pg_temp as $$
declare uid uuid:=auth.uid(); d date; n smallint; amount integer; bal bigint; led uuid;
begin
 if uid is null then raise exception 'authentication required' using errcode='28000'; end if;
 d:=(now() at time zone 'utc')::date; n:=extract(isodow from (now() at time zone 'utc'))::smallint;
 amount:=case n when 1 then 50 when 2 then 100 when 3 then 100 when 4 then 150 when 5 then 150 when 6 then 200 when 7 then 250 end;
 insert into public.wallets(user_id,coin_balance) values(uid,0) on conflict(user_id) do nothing;
 select coin_balance into bal from public.wallets where user_id=uid for update;
 insert into public.wallet_ledger(user_id,kind,coin_delta,idempotency_key,metadata) values(uid,'reward',amount,'daily:'||d::text,jsonb_build_object('day',n)) returning id into led;
 insert into public.daily_reward_claims(user_id,claim_date,day_no,coins,ledger_id) values(uid,d,n,amount,led);
 update public.wallets set coin_balance=coin_balance+amount,updated_at=now() where user_id=uid returning coin_balance into bal;
 return query select d,n,amount,bal;
end $$;
revoke all on function public.claim_daily_reward() from public, anon;
grant execute on function public.claim_daily_reward() to authenticated;
-- No client insert/update policy for wallets, ledger, claims, gifts, gift events, roles, audit logs, room secrets, or moderation decisions.
